function onMouseUp(event) {
	var myPath = new Path();
	myPath.strokeColor = 'red';
	myPath.add(event.downPoint);
	myPath.add(event.point);
}